Studio Dominique Soucy — website handoff package

Contains:
- latest approved homepage / Studio Map visual
- broader visual direction overview
- Claude Code master brief

Use the written brief as source of truth.
Use the images as visual references, not literal pixel-perfect screenshots to hardcode.
