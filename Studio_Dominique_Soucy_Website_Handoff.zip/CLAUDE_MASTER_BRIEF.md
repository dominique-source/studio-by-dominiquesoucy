# Studio Dominique Soucy — Master Brief for Claude Code

Goal: improve the existing Studio Dominique Soucy website, not rebuild blindly.

The site should present Studio Dominique Soucy as a venture studio / creative studio with a living ecosystem:
- Core: Dominique / Studio
- Closest strategic pillars: PürInstinct, Ballers Only, Gamification
- Transversal engine: Instinct Studio
- Incubation: Inner Game, In Five, Quartier Sportif
- Laboratories / real-world testing: Alérions, Cadet, Espace Y
- Partners: Éphèse, Espace Y, others
- Legacy / thought: Manipule le jeu, Manifeste Vol. 2
- Services: Conferences
- External orbit: App Ludo and other collaborations

Key principle:
The website must make the logic visible so visitors understand that many projects are expressions of one coherent worldview around sport, human development, community, technology, media, entrepreneurship, and focus.

Design direction:
- premium
- dark cinematic
- editorial
- artistic
- sporty without cliché
- calm despite complexity
- warm gold / amber accents
- strong photography and generous negative space
- mobile first, desktop second
- do not use generic SaaS layouts
- do not use fake quotes or invented project facts

Main visual idea:
A living Studio Map where projects can move closer to or farther from the core over time.

Suggested high-level navigation:
- Home
- Studio Map
- Ventures
- Labs
- Partners
- Reflections
- About

Important classifications:
PürInstinct = core flagship venture
Ballers Only = core community/youth platform
Gamification = core independent venture concept
Instinct Studio = transversal media/content/production engine
Quartier Sportif = visionary infrastructure project
Inner Game = autonomous product in incubation
In Five = strategic dormant venture waiting for operator/CEO
Alérions = school laboratory / impact project
Cadet = personal commitment / field research
Éphèse = client + strategic partner + partnership laboratory
Espace Y = client/partner/infrastructure lab
Manipule le jeu = foundational IP / legacy
Manifeste Vol. 2 = long-form thought leadership / book in development
Conferences = structured Studio service
Baller App = Ballers Only digital product, linked to Gamification
App Ludo = external orbit / collaboration
5D Athlete = to clarify / in development

Public/private:
Some projects may show public overview while investor/partner detail can be protected.
Do not use insecure client-side hardcoded passwords.

Technical direction:
- inspect current repo first
- preserve useful existing work
- create a maintainable project registry/data model
- map should be data-driven
- mobile map must be usable, not just visually impressive on desktop
- project status should be editable without rewriting UI
- statuses may include CORE, ACTIVE, BUILDING, INCUBATION, LABORATORY, PARTNER, LEGACY, PRIVATE, DORMANT, EXTERNAL ORBIT, IN DEVELOPMENT

Before coding, return:
1. understanding of the Studio
2. audit of current website
3. proposed information architecture
4. proposed Studio Map model
5. classification table for all projects
6. data model
7. mobile-first behavior
8. private-content strategy
9. migration plan
10. unresolved questions only
11. first implementation milestone

Then stop and wait for approval before production code.
